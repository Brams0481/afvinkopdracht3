# Startcode_Afvinkopdracht3

TODO:
* Initieer je lokale repo
* Pull de code van deze repo
* Kijk rustig naar de code en probeer deze te volgen
* Voer de code een keertje uit
* Maak wijzigingen in de meegeleverde code
* Commit wijzigingen
* Push de commits naar de opdracht
